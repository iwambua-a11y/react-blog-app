import React, { useState } from 'react';

export default function CommentForm({ onAddComment }) {
  const [name, setName] = useState('');
  const [commentText, setCommentText] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim() || !commentText.trim()) return;

    onAddComment({
      id: Date.now(),
      name: name.trim(),
      text: commentText.trim()
    });

    setName('');
    setCommentText('');
  };

  return (
    <form onSubmit={handleSubmit} className="comment-form">
      <h4>Leave a Comment</h4>
      <input
        type="text"
        className="form-input"
        placeholder="Your Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <textarea
        rows="3"
        className="form-textarea"
        placeholder="Your Comment"
        value={commentText}
        onChange={(e) => setCommentText(e.target.value)}
        required
      />
      <button type="submit" className="submit-btn">
        Submit Comment
      </button>
    </form>
  );
}