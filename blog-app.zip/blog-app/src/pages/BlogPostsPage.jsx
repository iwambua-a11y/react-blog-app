import React from 'react';
import { Link } from 'react-router-dom';

export default function BlogPostsPage({ posts }) {
  return (
    <div className="page-container">
      <h2 className="page-heading">Latest Posts</h2>
      <div className="posts-grid">
        {posts.map((post) => (
          <article key={post.id} className="post-card preview-card">
            <h3 className="post-title">
              <Link to={`/post/${post.id}`}>{post.title}</Link>
            </h3>
            <p className="post-meta">By {post.author} • {post.date}</p>
            <p className="post-body">
              {post.content.length > 130 
                ? `${post.content.substring(0, 130)}...` 
                : post.content}
            </p>
            <Link to={`/post/${post.id}`} className="read-more-link">
              Read Full Post &rarr;
            </Link>
          </article>
        ))}
      </div>
    </div>
  );
}