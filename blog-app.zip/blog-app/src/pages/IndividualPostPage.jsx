import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import CommentForm from '../components/CommentForm';

export default function IndividualPostPage({ posts }) {
  const { id } = useParams();
  const post = posts.find((p) => String(p.id) === String(id));

  const [comments, setComments] = useState([
    { id: 1, name: "Jordan Smith", text: "Great introductory read, thank you for sharing!" }
  ]);

  if (!post) {
    return (
      <div className="page-container">
        <h2>Post Not Found</h2>
        <p>The post you are looking for does not exist.</p>
        <Link to="/" className="back-link">&larr; Back to all posts</Link>
      </div>
    );
  }

  const handleAddComment = (newComment) => {
    setComments((prev) => [...prev, newComment]);
  };

  return (
    <div className="page-container">
      <Link to="/" className="back-link">&larr; Back to all posts</Link>
      <article className="post-card detail-card">
        <h2 className="post-title">{post.title}</h2>
        <div className="post-meta">
          <p><strong>Author:</strong> {post.author}</p>
          <p><strong>Date:</strong> {post.date}</p>
        </div>
        <div className="post-body full-content">
          <p>{post.content}</p>
        </div>

        <section className="comments-section">
          <h3 className="section-heading">Comments</h3>
          
          <CommentForm onAddComment={handleAddComment} />

          <div className="existing-comments">
            <h4 className="comments-label">Discussion</h4>
            {comments.length === 0 ? (
              <p className="no-comments-msg">No comments yet. Be the first to comment!</p>
            ) : (
              <ul className="comments-list">
                {comments.map((c) => (
                  <li key={c.id} className="comment-bubble">
                    <p className="comment-author"><strong>{c.name}</strong></p>
                    <p className="comment-body">{c.text}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </article>
    </div>
  );
}