import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import BlogPostsPage from './pages/BlogPostsPage';
import IndividualPostPage from './pages/IndividualPostPage';
import ContactPage from './pages/ContactPage';
import './App.css';

const blogPostsData = [
  {
    id: 1,
    title: "Getting Started with React and Single Page Apps",
    author: "Ian Wambua",
    date: "2026-10-18",
    content: "Single page applications (SPAs) allow modern web developers to deliver seamless user experiences without requiring constant browser reloads. In React, components dictate the view layer while client-side routers manage stateful transitions across URLs."
  },
  {
    id: 2,
    title: "Understanding React Router and Dynamic Route Parameters",
    author: "Ian Wambua",
    date: "2026-10-22",
    content: "Dynamic routing enables applications to match pattern-based URLs such as /post/:id. Utilizing hooks like useParams allows component trees to fetch and render specific data sets corresponding directly to browser address bar parameters."
  },
  {
    id: 3,
    title: "State Management & The Context API for Global Theming",
    author: "Ian Wambua",
    date: "2026-10-28",
    content: "React's useContext API eliminates prop drilling by allowing developers to broadcast application-wide state, like dark/light themes and authentication data, directly to any consumer component in the tree."
  }
];

function MainContent() {
  const { theme } = useTheme();

  return (
    <div className={`app-shell ${theme}`}>
      <Navbar />
      <main className="content-area">
        <Routes>
          <Route path="/" element={<BlogPostsPage posts={blogPostsData} />} />
          <Route path="/post/:id" element={<IndividualPostPage posts={blogPostsData} />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <ThemeProvider>
        <MainContent />
      </ThemeProvider>
    </Router>
  );
}